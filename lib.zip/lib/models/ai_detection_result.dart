import 'moderation_result.dart';

/// Response model for the NOAI AI Detection API.
class AiDetectionResult {
  final String analysisId;

  /// Classification: "AI-GENERATED", "LIKELY AI-GENERATED",
  /// "LIKELY HUMAN-GENERATED", "HUMAN-GENERATED"
  final String result;
  final double confidence; // 0-100
  final String contentType; // "text", "image", "mixed"
  final String? consensusStrength;
  final String? rationale;
  final List<String>? combinedEvidence;
  final MetadataAnalysis? metadataAnalysis;
  final List<ModelResult>? modelResults;
  final ModerationResult? moderation;
  final double? safetyScore;

  AiDetectionResult({
    required this.analysisId,
    required this.result,
    required this.confidence,
    required this.contentType,
    this.consensusStrength,
    this.rationale,
    this.combinedEvidence,
    this.metadataAnalysis,
    this.modelResults,
    this.moderation,
    this.safetyScore,
  });

  factory AiDetectionResult.fromJson(Map<String, dynamic> json) {
    return AiDetectionResult(
      analysisId: json['analysis_id'] as String? ?? '',
      result: (json['result'] as String? ?? 'HUMAN-GENERATED')
          .trim()
          .toUpperCase(),
      confidence: (json['confidence'] as num?)?.toDouble() ?? 0.0,
      contentType: json['content_type'] as String? ?? '',
      consensusStrength: json['consensus_strength'] as String?,
      rationale: json['rationale'] as String?,
      combinedEvidence: (json['combined_evidence'] as List<dynamic>?)
          ?.map((e) => e.toString())
          .toList(),
      metadataAnalysis: json['metadata_analysis'] != null
          ? MetadataAnalysis.fromJson(
              json['metadata_analysis'] as Map<String, dynamic>,
            )
          : null,
      modelResults: (json['model_results'] as List<dynamic>?)
          ?.map((e) => ModelResult.fromJson(e as Map<String, dynamic>))
          .toList(),
      moderation: json['moderation'] != null
          ? ModerationResult.fromJson(
              json['moderation'] as Map<String, dynamic>,
            )
          : null,
      safetyScore: (json['safety_score'] as num?)?.toDouble(),
    );
  }

  Map<String, dynamic> toJson() {
    return {
      'analysis_id': analysisId,
      'result': result,
      'confidence': confidence,
      'content_type': contentType,
      'consensus_strength': consensusStrength,
      'rationale': rationale,
      'combined_evidence': combinedEvidence,
      'metadata_analysis': metadataAnalysis?.toJson(),
      'model_results': modelResults?.map((e) => e.toJson()).toList(),
      'moderation': moderation?.toJson(),
      'safety_score': safetyScore,
    };
  }
}

class MetadataAnalysis {
  final double? adjustment;
  final List<String> signals;

  MetadataAnalysis({this.adjustment, required this.signals});

  factory MetadataAnalysis.fromJson(Map<String, dynamic> json) {
    return MetadataAnalysis(
      adjustment: (json['adjustment'] as num?)?.toDouble(),
      signals:
          (json['signals'] as List<dynamic>?)
              ?.map((e) => e.toString())
              .toList() ??
          [],
    );
  }

  Map<String, dynamic> toJson() {
    return {'adjustment': adjustment, 'signals': signals};
  }
}

class ModelResult {
  final String model;
  final String result;
  final double confidence;
  final String? reasoning;

  ModelResult({
    required this.model,
    required this.result,
    required this.confidence,
    this.reasoning,
  });

  factory ModelResult.fromJson(Map<String, dynamic> json) {
    return ModelResult(
      model: json['model'] as String? ?? '',
      result: json['result'] as String? ?? '',
      confidence: (json['confidence'] as num?)?.toDouble() ?? 0.0,
      reasoning: json['reasoning'] as String?,
    );
  }

  Map<String, dynamic> toJson() {
    return {
      'model': model,
      'result': result,
      'confidence': confidence,
      'reasoning': reasoning,
    };
  }
}
